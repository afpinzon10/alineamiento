package parte1;

public interface Predicate {

	public boolean evaluarPredicado(Object object);
}
