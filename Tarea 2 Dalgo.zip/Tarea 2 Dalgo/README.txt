Andres Felipe Pinzon Adame - 201518804
Zulma Lorena Casta�eda Hidalgo - 201518119


INSTRUCCIONES:

Insercion de parametros:
Antes de ejecutar el proyecto desde eclipse ingresar los siguientes parametros:

Main class: ejercicio.ExampleIterator
Argumentos
n: numero de la secuencia deseado

Ejercicios de clase

1.x= raiz(n): iterators.Root n
2.Fibonacci: iterators.Fibonacci n
3.Busqueda binaria: iterators.BinarySearch n
4.Numeros primos: iterators.Primos n

Tarea
Main class: parte1.P1Main
1.Primo mayor a 100k: iterators.Primos 10000

2. Main class: parte2.P2Main
Argumentos: 
Recorrido filas: data\matrix n iterators.MIByRows
Recorrido columnas: data\matrix n iterators.MIByCols
Recorrido diagonal: data\matrix n iterators.MIByDiags


Formato archivo de la matriz

La matriz debe estar en un archivo de formato texto plano e iniciar unicamente con los datos. La matriz debe ser cuadrada.
Ejemplo (Matriz 3x3):
123
456
789
Esta matriz de ejemplo se encuentra en la carpeta data del proyecto
